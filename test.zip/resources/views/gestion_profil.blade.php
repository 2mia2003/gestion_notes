@extends('layouts.app')
@section('title','Gestion du Profil')

@section('content')
<div class="max-w-[960px] mx-auto flex flex-col gap-8 pb-20">

    <!-- Breadcrumbs -->
    <nav class="flex flex-wrap gap-2 items-center">
        <a class="text-[#4c669a] dark:text-gray-400 text-sm font-medium leading-normal hover:text-primary transition-colors"
           href="{{ route('accueil') }}">Accueil</a>

        <span class="text-[#4c669a] dark:text-gray-400 text-sm font-medium leading-normal">/</span>

        <a class="text-[#4c669a] dark:text-gray-400 text-sm font-medium leading-normal hover:text-primary transition-colors"
           href="{{ route('parametres') }}">Paramètres</a>

        <span class="text-[#4c669a] dark:text-gray-400 text-sm font-medium leading-normal">/</span>

        <span class="text-[#0d121b] dark:text-white text-sm font-medium leading-normal">Gestion du Profil</span>
    </nav>

    <!-- Page Header -->
    <div class="flex flex-wrap justify-between gap-3">
        <div class="flex min-w-72 flex-col gap-2">
            <h1 class="text-[#0d121b] dark:text-white text-3xl font-bold leading-tight tracking-[-0.02em]">Profil et Compte</h1>
            <p class="text-[#4c669a] dark:text-gray-400 text-base font-normal leading-normal">
                Gérez vos informations personnelles, votre rôle et la sécurité de votre compte.
            </p>
        </div>

        <button class="flex items-center justify-center gap-2 rounded-lg bg-primary h-10 px-6 text-white text-sm font-bold shadow-sm hover:bg-blue-700 transition-colors">
            <span>Sauvegarder</span>
        </button>
    </div>

    <!-- Profile Avatar Card -->
    <section class="bg-white dark:bg-[#1a2230] rounded-xl border border-[#e7ebf3] dark:border-gray-800 p-6 shadow-sm">
        <div class="flex w-full flex-col gap-6 md:flex-row md:justify-between md:items-center">
            <div class="flex gap-6 items-center">
                <div class="bg-center bg-no-repeat bg-cover rounded-full h-24 w-24 ring-4 ring-gray-50 dark:ring-gray-800"
                     style='background-image: url("https://i.pravatar.cc/150");'>
                </div>

                <div class="flex flex-col justify-center gap-1">
                    <h3 class="text-[#0d121b] dark:text-white text-xl font-bold leading-tight">
                        {{ auth()->user()->name }}
                    </h3>

                    <p class="text-[#4c669a] dark:text-gray-400 text-sm font-normal">
                        {{ auth()->user()->email }}
                    </p>

                    <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 mt-2 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300 w-fit">
                        <span class="material-symbols-outlined text-[14px]">verified_user</span>
                        Administrateur
                    </span>
                </div>
            </div>

            <button class="flex min-w-[84px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#f0f2f5] dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors text-[#0d121b] dark:text-white text-sm font-bold w-full md:w-auto">
                <span class="truncate">Changer l'avatar</span>
            </button>
        </div>
    </section>

    <!-- Personal Information Form -->
    <section class="bg-white dark:bg-[#1a2230] rounded-xl border border-[#e7ebf3] dark:border-gray-800 p-6 shadow-sm">
        <div class="flex items-center gap-3 mb-6 border-b border-[#e7ebf3] dark:border-gray-800 pb-4">
            <span class="material-symbols-outlined text-primary">person</span>
            <h2 class="text-lg font-bold text-[#0d121b] dark:text-white">Informations Personnelles</h2>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="flex flex-col gap-2">
                <label class="text-[#0d121b] dark:text-gray-200 text-sm font-medium" for="firstName">Prénom</label>
                <input class="bg-[#f8f9fc] dark:bg-gray-800 border border-[#e7ebf3] dark:border-gray-700 text-[#0d121b] dark:text-white text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5"
                       id="firstName" placeholder="Votre prénom" type="text" value=""/>
            </div>

            <div class="flex flex-col gap-2">
                <label class="text-[#0d121b] dark:text-gray-200 text-sm font-medium" for="lastName">Nom</label>
                <input class="bg-[#f8f9fc] dark:bg-gray-800 border border-[#e7ebf3] dark:border-gray-700 text-[#0d121b] dark:text-white text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5"
                       id="lastName" placeholder="Votre nom" type="text" value=""/>
            </div>

            <div class="flex flex-col gap-2">
                <label class="text-[#0d121b] dark:text-gray-200 text-sm font-medium" for="email">Adresse Email</label>
                <input class="bg-[#f8f9fc] dark:bg-gray-800 border border-[#e7ebf3] dark:border-gray-700 text-[#0d121b] dark:text-white text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5"
                       id="email" placeholder="exemple@domaine.com" type="email" value="{{ auth()->user()->email }}"/>
            </div>

            <div class="flex flex-col gap-2">
                <label class="text-[#0d121b] dark:text-gray-200 text-sm font-medium" for="phone">Téléphone</label>
                <input class="bg-[#f8f9fc] dark:bg-gray-800 border border-[#e7ebf3] dark:border-gray-700 text-[#0d121b] dark:text-white text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5"
                       id="phone" placeholder="+221 ..." type="tel" value=""/>
            </div>

            <div class="flex flex-col gap-2 md:col-span-2">
                <label class="text-[#0d121b] dark:text-gray-200 text-sm font-medium" for="department">Département Académique</label>
                <select class="bg-[#f8f9fc] dark:bg-gray-800 border border-[#e7ebf3] dark:border-gray-700 text-[#0d121b] dark:text-white text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5" id="department">
                    <option value="cs">Informatique &amp; Sciences du Numérique</option>
                    <option value="math">Mathématiques</option>
                    <option value="phys">Physique</option>
                    <option value="lit">Littérature</option>
                </select>
            </div>
        </div>
    </section>

    <!-- Roles & Permissions -->
    <section class="bg-white dark:bg-[#1a2230] rounded-xl border border-[#e7ebf3] dark:border-gray-800 p-6 shadow-sm">
        <div class="flex items-center gap-3 mb-6 border-b border-[#e7ebf3] dark:border-gray-800 pb-4">
            <span class="material-symbols-outlined text-primary">shield_person</span>
            <h2 class="text-lg font-bold text-[#0d121b] dark:text-white">Rôles et Autorisations</h2>
        </div>

        <div class="flex flex-col gap-6">
            <div class="flex items-start gap-4 p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800">
                <span class="material-symbols-outlined text-primary mt-0.5">info</span>
                <div>
                    <p class="text-sm font-medium text-[#0d121b] dark:text-white">
                        Votre rôle actuel est : <span class="font-bold text-primary">Administrateur</span>
                    </p>
                    <p class="text-sm text-[#4c669a] dark:text-gray-400 mt-1">
                        Les administrateurs ont un accès complet pour gérer les utilisateurs, les archives et les paramètres système.
                    </p>
                </div>
            </div>

            <div>
                <h3 class="text-sm font-bold text-[#0d121b] dark:text-white mb-3 uppercase tracking-wider text-xs">
                    Autorisations actives
                </h3>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div class="flex items-center gap-2 text-sm text-[#4c669a] dark:text-gray-300">
                        <span class="material-symbols-outlined text-green-500 text-[20px]">check_circle</span>
                        Scanner et importer des notes
                    </div>
                    <div class="flex items-center gap-2 text-sm text-[#4c669a] dark:text-gray-300">
                        <span class="material-symbols-outlined text-green-500 text-[20px]">check_circle</span>
                        Modifier les archives
                    </div>
                    <div class="flex items-center gap-2 text-sm text-[#4c669a] dark:text-gray-300">
                        <span class="material-symbols-outlined text-green-500 text-[20px]">check_circle</span>
                        Gérer les comptes utilisateurs
                    </div>
                    <div class="flex items-center gap-2 text-sm text-[#4c669a] dark:text-gray-300">
                        <span class="material-symbols-outlined text-green-500 text-[20px]">check_circle</span>
                        Accès aux logs de sécurité
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Security Section -->
    <section class="bg-white dark:bg-[#1a2230] rounded-xl border border-[#e7ebf3] dark:border-gray-800 p-6 shadow-sm">
        <div class="flex items-center gap-3 mb-6 border-b border-[#e7ebf3] dark:border-gray-800 pb-4">
            <span class="material-symbols-outlined text-primary">lock_reset</span>
            <h2 class="text-lg font-bold text-[#0d121b] dark:text-white">Sécurité du Compte</h2>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">

            <!-- Change Password -->
            <div class="flex flex-col gap-4">
                <h3 class="text-base font-bold text-[#0d121b] dark:text-white">Changer le mot de passe</h3>

                <div class="flex flex-col gap-3">
                    <div class="flex flex-col gap-1">
                        <label class="text-[#4c669a] dark:text-gray-400 text-xs font-medium uppercase" for="currentPwd">Mot de passe actuel</label>
                        <div class="relative">
                            <input class="bg-[#f8f9fc] dark:bg-gray-800 border border-[#e7ebf3] dark:border-gray-700 text-[#0d121b] dark:text-white text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5 pr-10"
                                   id="currentPwd" type="password"/>
                            <button type="button" class="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
                                <span class="material-symbols-outlined text-[20px]">visibility</span>
                            </button>
                        </div>
                    </div>

                    <div class="flex flex-col gap-1">
                        <label class="text-[#4c669a] dark:text-gray-400 text-xs font-medium uppercase" for="newPwd">Nouveau mot de passe</label>
                        <input class="bg-[#f8f9fc] dark:bg-gray-800 border border-[#e7ebf3] dark:border-gray-700 text-[#0d121b] dark:text-white text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5"
                               id="newPwd" type="password"/>
                    </div>

                    <div class="flex flex-col gap-1">
                        <label class="text-[#4c669a] dark:text-gray-400 text-xs font-medium uppercase" for="confirmPwd">Confirmer le mot de passe</label>
                        <input class="bg-[#f8f9fc] dark:bg-gray-800 border border-[#e7ebf3] dark:border-gray-700 text-[#0d121b] dark:text-white text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2.5"
                               id="confirmPwd" type="password"/>
                    </div>

                    <button type="button" class="mt-2 w-fit px-4 py-2 bg-white dark:bg-gray-700 border border-[#e7ebf3] dark:border-gray-600 rounded-lg text-sm font-medium text-[#0d121b] dark:text-white hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors">
                        Mettre à jour
                    </button>
                </div>
            </div>

            <!-- 2FA & Sessions -->
            <div class="flex flex-col gap-6">
                <div class="flex flex-col gap-4">
                    <h3 class="text-base font-bold text-[#0d121b] dark:text-white">Authentification à deux facteurs (2FA)</h3>

                    <div class="flex items-center justify-between p-4 rounded-lg border border-[#e7ebf3] dark:border-gray-700 bg-[#f8f9fc] dark:bg-gray-800/50">
                        <div class="flex flex-col">
                            <span class="text-sm font-medium text-[#0d121b] dark:text-white">Activer 2FA</span>
                            <span class="text-xs text-[#4c669a] dark:text-gray-400">Sécurisez votre compte avec un code SMS.</span>
                        </div>

                        <label class="relative inline-flex items-center cursor-pointer">
                            <input checked class="sr-only peer" type="checkbox" value=""/>
                            <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary"></div>
                        </label>
                    </div>
                </div>

                <div class="flex flex-col gap-4">
                    <h3 class="text-base font-bold text-[#0d121b] dark:text-white">Sessions actives</h3>
                    <p class="text-sm text-[#4c669a] dark:text-gray-400">
                        Dernière connexion : <span class="font-medium text-[#0d121b] dark:text-gray-200">Aujourd'hui</span>
                    </p>

                    <button type="button" class="flex items-center justify-center gap-2 w-full px-4 py-2.5 rounded-lg border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 text-sm font-bold hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors">
                        <span class="material-symbols-outlined text-[18px]">logout</span>
                        Déconnecter les autres sessions
                    </button>
                </div>
            </div>

        </div>
    </section>

</div>
@endsection

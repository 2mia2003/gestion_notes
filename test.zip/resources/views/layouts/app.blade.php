<!DOCTYPE html>
<html lang="fr" class="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'GradeScanner Pro')</title>

    {{-- Fonts --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700&family=Noto+Sans:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">

    {{-- Tailwind --}}
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        body {
            font-family: 'Lexend', 'Noto Sans', sans-serif;
        }
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
            font-size: 24px;
        }
        .material-symbols-outlined.fill {
            font-variation-settings: 'FILL' 1;
        }
    </style>
</head>

<body class="bg-background-light dark:bg-background-dark text-[#0d121b] dark:text-white">

<div class="flex h-screen overflow-hidden">

    {{-- ================= SIDEBAR ================= --}}
    <aside class="hidden lg:flex flex-col w-72 bg-white dark:bg-[#1a2230] border-r border-[#e7ebf3] dark:border-gray-800">

        <div class="flex flex-col p-6 h-full justify-between">

            <div class="flex flex-col gap-6">
                <div>
                    <h1 class="text-lg font-bold">Paramètres</h1>
                    <p class="text-sm text-[#4c669a] dark:text-gray-400">Gestion du compte</p>
                </div>

                <nav class="flex flex-col gap-2">
                    <a href="{{ route('gestion.profil') }}"
                       class="flex items-center gap-3 px-3 py-2.5 rounded-lg
                       {{ request()->routeIs('gestion.profil') ? 'bg-primary/10 border-l-4 border-primary text-primary font-bold' : 'hover:bg-gray-50 dark:hover:bg-gray-800 text-[#4c669a] dark:text-gray-400' }}">
                        <span class="material-symbols-outlined">person</span>
                        Informations Personnelles
                    </a>

                    <a href="{{ route('parametres') }}"
                       class="flex items-center gap-3 px-3 py-2.5 rounded-lg
                       {{ request()->routeIs('parametres') ? 'bg-primary/10 border-l-4 border-primary text-primary font-bold' : 'hover:bg-gray-50 dark:hover:bg-gray-800 text-[#4c669a] dark:text-gray-400' }}">
                        <span class="material-symbols-outlined">settings</span>
                        Paramètres
                    </a>

                    <a href="{{ route('accueil') }}"
                       class="flex items-center gap-3 px-3 py-2.5 rounded-lg
                       {{ request()->routeIs('accueil') ? 'bg-primary/10 border-l-4 border-primary text-primary font-bold' : 'hover:bg-gray-50 dark:hover:bg-gray-800 text-[#4c669a] dark:text-gray-400' }}">
                        <span class="material-symbols-outlined">home</span>
                        Accueil
                    </a>
                </nav>
            </div>

            <div class="p-4 rounded-xl bg-gray-50 dark:bg-gray-800 border border-[#e7ebf3] dark:border-gray-700">
                <p class="text-xs text-[#4c669a] dark:text-gray-400 mb-2">Besoin d'aide ?</p>
                <a href="#" class="text-sm text-primary font-medium hover:underline">Contactez le support</a>
            </div>

        </div>
    </aside>

    {{-- ================= MAIN ================= --}}
    <div class="flex flex-col flex-1 overflow-hidden">

        {{-- ===== TOPBAR ===== --}}
        <header class="flex items-center justify-between border-b border-[#e7ebf3] dark:border-gray-800 bg-white dark:bg-[#1a2230] px-6 py-3 shrink-0">
            <div class="flex items-center gap-4">
                <span class="text-lg font-bold">GradeScanner Pro</span>
            </div>

            <div class="flex items-center gap-4">
                <span class="text-sm">{{ auth()->user()->email }}</span>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button class="px-4 py-2 bg-primary text-white rounded-lg text-sm font-bold hover:bg-blue-700">
                        Déconnexion
                    </button>
                </form>
            </div>
        </header>

        {{-- ===== CONTENU ===== --}}
        <main class="flex-1 overflow-y-auto bg-background-light dark:bg-background-dark">
            {{-- espace ENTRE topbar et contenu --}}
            <div class="p-4 lg:p-10 pt-8 lg:pt-10">
                @yield('content')
            </div>
        </main>

    </div>

</div>

</body>
</html>

@extends('layouts.app')
@section('title','Accueil')

@section('content')
<div class="max-w-[960px] mx-auto flex flex-col gap-8 pb-20">

    <nav class="flex flex-wrap gap-2 items-center">
        <span class="text-[#0d121b] dark:text-white text-sm font-medium leading-normal">Accueil</span>
    </nav>

    <div class="flex flex-col gap-2">
        <h1 class="text-[#0d121b] dark:text-white text-3xl font-bold leading-tight tracking-[-0.02em]">
            Accueil
        </h1>

        <p class="text-[#4c669a] dark:text-gray-400">
            Bienvenue {{ auth()->user()->name }}
        </p>
    </div>

</div>
@endsection

<!DOCTYPE html>
<html lang="fr" class="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>@yield('title','GradeScanner Pro')</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700&family=Noto+Sans:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght@100..700&display=swap" rel="stylesheet">

    <!-- Tailwind via Vite -->
    @vite(['resources/css/app.css','resources/js/app.js'])
</head>

<body class="bg-background-light dark:bg-background-dark text-[#0d121b] dark:text-white font-[Lexend]">

<div class="flex h-screen overflow-hidden">

    <!-- ================= SIDEBAR ================= -->
    <aside class="hidden lg:flex flex-col w-72 bg-white dark:bg-[#1a2230] border-r border-[#e7ebf3] dark:border-gray-800">
        <div class="p-6 flex flex-col gap-6 flex-1">

            <div>
                <h1 class="text-lg font-bold">Paramètres</h1>
                <p class="text-sm text-[#4c669a] dark:text-gray-400">Gestion du compte</p>
            </div>

            <nav class="flex flex-col gap-2">

                <a href="{{ route('accueil') }}"
                   class="flex items-center gap-3 px-3 py-2.5 rounded-lg
                   {{ request()->routeIs('accueil')
                        ? 'bg-primary/10 border-l-4 border-primary text-primary font-bold'
                        : 'hover:bg-gray-50 dark:hover:bg-gray-800 text-[#4c669a] dark:text-gray-400' }}">
                    <span class="material-symbols-outlined">home</span>
                    Accueil
                </a>

                <a href="{{ route('parametres') }}"
                   class="flex items-center gap-3 px-3 py-2.5 rounded-lg
                   {{ request()->routeIs('parametres')
                        ? 'bg-primary/10 border-l-4 border-primary text-primary font-bold'
                        : 'hover:bg-gray-50 dark:hover:bg-gray-800 text-[#4c669a] dark:text-gray-400' }}">
                    <span class="material-symbols-outlined">settings</span>
                    Paramètres
                </a>

                <a href="{{ route('gestion.profil') }}"
                   class="flex items-center gap-3 px-3 py-2.5 rounded-lg
                   {{ request()->routeIs('gestion.profil')
                        ? 'bg-primary/10 border-l-4 border-primary text-primary font-bold'
                        : 'hover:bg-gray-50 dark:hover:bg-gray-800 text-[#4c669a] dark:text-gray-400' }}">
                    <span class="material-symbols-outlined">person</span>
                    Gestion du profil
                </a>

            </nav>
        </div>

        <div class="p-4 border-t border-[#e7ebf3] dark:border-gray-800">
            <p class="text-xs text-[#4c669a] dark:text-gray-400 mb-1">Besoin d’aide ?</p>
            <a href="#" class="text-sm text-primary font-medium hover:underline">Contact support</a>
        </div>
    </aside>

    <!-- ================= MAIN ================= -->
    <div class="flex flex-col flex-1 overflow-hidden">

        <!-- ========== TOPBAR ========== -->
        <header class="flex items-center justify-between px-6 py-3 bg-white dark:bg-[#1a2230] border-b border-[#e7ebf3] dark:border-gray-800">
            <h2 class="text-lg font-bold">GradeScanner Pro</h2>

            <nav class="hidden lg:flex items-center gap-8">
                <a href="{{ route('accueil') }}"
                   class="{{ request()->routeIs('accueil') ? 'text-primary font-bold' : 'text-gray-600 dark:text-gray-300' }}">
                    Accueil
                </a>
                <a href="{{ route('parametres') }}"
                   class="{{ request()->routeIs('parametres') ? 'text-primary font-bold' : 'text-gray-600 dark:text-gray-300' }}">
                    Paramètres
                </a>
                <a href="{{ route('gestion.profil') }}"
                   class="{{ request()->routeIs('gestion.profil') ? 'text-primary font-bold' : 'text-gray-600 dark:text-gray-300' }}">
                    Gestion profil
                </a>
            </nav>

            <div class="flex items-center gap-4">
                <span class="text-sm">{{ auth()->user()->name }}</span>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button class="text-sm text-red-500">Déconnexion</button>
                </form>
            </div>
        </header>

        <!-- ========== CONTENT ========== -->
        <main class="flex-1 overflow-y-auto p-6 bg-background-light dark:bg-background-dark">
            @yield('content')
        </main>

    </div>
</div>

</body>
</html>

@extends('layouts.app')
@section('title','Paramètres')

@section('content')
<div class="max-w-[960px] mx-auto flex flex-col gap-8 pb-20">

    <nav class="flex flex-wrap gap-2 items-center">
        <a class="text-[#4c669a] dark:text-gray-400 text-sm font-medium leading-normal hover:text-primary transition-colors"
           href="{{ route('accueil') }}">Accueil</a>

        <span class="text-[#4c669a] dark:text-gray-400 text-sm font-medium leading-normal">/</span>

        <span class="text-[#0d121b] dark:text-white text-sm font-medium leading-normal">Paramètres</span>
    </nav>

    <div class="flex flex-col gap-2">
        <h1 class="text-[#0d121b] dark:text-white text-3xl font-bold leading-tight tracking-[-0.02em]">Paramètres</h1>
        <p class="text-[#4c669a] dark:text-gray-400">Page paramètres générale.</p>
    </div>

</div>
@endsection

<?php

use Illuminate\Support\Facades\Route;

Route::middleware(['auth'])->group(function () {

    Route::get('/dashboard', function () {
        return redirect()->route('accueil');
    })->name('dashboard');

    Route::get('/accueil', function () {
        return view('accueil');
    })->name('accueil');

    Route::get('/parametres', function () {
        return view('parametres');
    })->name('parametres');
});

require __DIR__.'/auth.php';

@extends('layouts.app')

@section('title', 'Accueil')

@section('content')
<div class="max-w-4xl mx-auto flex flex-col gap-6">
    <h1 class="text-3xl font-bold">Accueil</h1>

    <p class="text-gray-500">
        Bienvenue <strong>{{ auth()->user()->name }}</strong>.
    </p>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white dark:bg-[#1a2230] p-5 rounded-xl border">
            <p class="text-sm text-gray-500">Feuilles numérisées</p>
            <p class="text-2xl font-bold">0</p>
        </div>
        <div class="bg-white dark:bg-[#1a2230] p-5 rounded-xl border">
            <p class="text-sm text-gray-500">Modules clôturés</p>
            <p class="text-2xl font-bold">0</p>
        </div>
        <div class="bg-white dark:bg-[#1a2230] p-5 rounded-xl border">
            <p class="text-sm text-gray-500">Erreurs OCR</p>
            <p class="text-2xl font-bold">0</p>
        </div>
    </div>
</div>
@endsection

<!DOCTYPE html>
<html class="light" lang="fr">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>@yield('title', 'GradeScanner Pro')</title>

    <link rel="preconnect" href="https://fonts.googleapis.com"/>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700&family=Noto+Sans:wght@400;500;700&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>

    @vite(['resources/css/app.css','resources/js/app.js'])
</head>

<body class="bg-background-light dark:bg-background-dark text-[#0d121b] dark:text-white">
<div class="flex h-screen flex-col">

    <!-- TOPBAR -->
    <header class="flex items-center justify-between border-b bg-white dark:bg-[#1a2230] px-6 py-3">
        <h2 class="text-lg font-bold">GradeScanner Pro</h2>

        <div class="flex items-center gap-6">
            <a href="{{ route('accueil') }}" class="font-medium hover:text-primary {{ request()->routeIs('accueil') ? 'text-primary' : '' }}">
                Accueil
            </a>
            <a href="{{ route('parametres') }}" class="font-medium hover:text-primary {{ request()->routeIs('parametres') ? 'text-primary' : '' }}">
                Paramètres
            </a>

            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="bg-primary text-white px-4 py-2 rounded-lg font-bold">
                    Déconnexion
                </button>
            </form>
        </div>
    </header>

    <div class="flex flex-1 overflow-hidden">

        <!-- SIDEBAR -->
        <aside class="hidden lg:flex w-64 flex-col bg-white dark:bg-[#1a2230] border-r p-6">
            <p class="text-sm text-gray-500 mb-2">Utilisateur</p>
            <p class="font-bold">{{ auth()->user()->name }}</p>
            <p class="text-sm text-gray-500">{{ auth()->user()->email }}</p>

            <div class="mt-8 flex flex-col gap-2">
                <a href="{{ route('accueil') }}" class="p-2 rounded {{ request()->routeIs('accueil') ? 'bg-primary/10 text-primary font-bold' : '' }}">
                    Accueil
                </a>
                <a href="{{ route('parametres') }}" class="p-2 rounded {{ request()->routeIs('parametres') ? 'bg-primary/10 text-primary font-bold' : '' }}">
                    Paramètres
                </a>
            </div>
        </aside>

        <!-- CONTENT -->
        <main class="flex-1 overflow-y-auto p-6">
            @yield('content')
        </main>

    </div>
</div>
</body>
</html>

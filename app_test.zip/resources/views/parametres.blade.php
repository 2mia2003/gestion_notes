@extends('layouts.app')

@section('title', 'Paramètres')

@section('content')
<div class="max-w-4xl mx-auto flex flex-col gap-6">

    <h1 class="text-3xl font-bold">Paramètres</h1>

    <section class="bg-white dark:bg-[#1a2230] border rounded-xl p-6">
        <h2 class="text-xl font-bold mb-4">Profil</h2>

        <p><strong>Nom :</strong> {{ auth()->user()->name }}</p>
        <p><strong>Email :</strong> {{ auth()->user()->email }}</p>
    </section>

    <section class="bg-white dark:bg-[#1a2230] border rounded-xl p-6">
        <h2 class="text-xl font-bold mb-4">Sécurité</h2>
        <p>Mot de passe, 2FA, sessions actives (à implémenter)</p>
    </section>

</div>
@endsection
